#include "ErrorEventListener.h"

ErrorEventListener::ErrorEventListener() {
}

ErrorEventListener::~ErrorEventListener() {
}

