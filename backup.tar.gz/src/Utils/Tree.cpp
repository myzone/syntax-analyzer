#include "Tree.h"

const TraverseType TraverseType::DEPTH_TRAVERSE = TraverseType("depth");
const TraverseType TraverseType::WIDTH_TRAVERSE = TraverseType("width");