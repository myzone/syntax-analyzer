#include "SyntaxTree.h"

SyntaxTree::SyntaxTree() {
}

SyntaxTree::~SyntaxTree() {
}