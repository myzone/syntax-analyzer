#include "EventListener.h"

namespace Events {

    EventListener::EventListener() {
    }

    EventListener::~EventListener() {
    }

}