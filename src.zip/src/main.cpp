/*
 * File:   main.cpp
 * Author: myzone
 *
 * Created on 1 February 2012 y., 18:03
 */

int main(int argc, char** argv) {

}
