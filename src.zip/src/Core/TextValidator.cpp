#include "TextValidator.h"

TextValidator::TextValidator ( ) {
}

TextValidator::~TextValidator ( ) { }

void TextValidator::validate(const QString& string, const ErrorEventBroadcaster& broadcaster) const {
    
}