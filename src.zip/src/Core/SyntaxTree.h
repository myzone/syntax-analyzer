#pragma once

class SyntaxTree {
public:
    SyntaxTree();
    virtual ~SyntaxTree();
};

