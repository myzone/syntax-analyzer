#pragma once

#ifndef null
#define null NULL
#endif

#ifndef File
#define File FILE
#endif

#ifndef throws
#define throws throw
#endif

#ifndef pure
#define pure =0
#endif